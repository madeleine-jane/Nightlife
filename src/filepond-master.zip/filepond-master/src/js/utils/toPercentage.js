export const toPercentage = value => Math.round(value * 100);
