export const toString = value => '' + value;
