import { createServerAPI } from './createServerAPI';
export const toServerAPI = value => createServerAPI(value);
